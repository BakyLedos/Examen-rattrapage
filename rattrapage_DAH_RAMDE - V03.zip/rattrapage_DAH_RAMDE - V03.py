# -*- coding: utf-8 -*-
"""
###############################################################
############# Membres du groupe ###############################
######### RAMDE Bakary & DAH D. Auguste Stanislas #############
###############################################################

Spyder Editor

This is a temporary script file.
"""
###############################################################################################
############# EXTRACTION DES CONCLUSIONS DES TROIS FICHIERS PLACES DANS UN DOSSIER ############
###############################################################################################
# liste des imports réalisés pour le programme
import PyPDF2
import re
import os
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
#from nltk.stem import PorterStemmer
from nltk.stem.snowball import SnowballStemmer
from sklearn.feature_extraction.text import CountVectorizer
#from sklearn.feature_extraction.text import LatentDirichletAllocation
from sklearn.decomposition import LatentDirichletAllocation
from wordcloud import WordCloud
import pandas as pd
import matplotlib.pyplot as plt



# listes des fonctions utilisées
def calcul_tf(tableau_stemmed):
    liste_tf=[]
    for titre, conclusion in tableau_stemmed.items():
        liste_temp=[]
        for word in uniqTokenList:
            liste_temp.append(conclusion.count(word)/len(conclusion))
        liste_tf.append(liste_temp)
    return liste_tf
    
def calcul_idf(liste_tf, uniqTokenList):
    liste_idf=[]
    for i,word in enumerate(uniqTokenList):
        compteur=0
        if liste_tf[0][i]>0:
            compteur+=1
        if liste_tf[1][i]>0:
            compteur+=1
        if liste_tf[2][i]>0:
            compteur+=1
        liste_idf.append(3/compteur)
    return liste_idf

def calcul_tf_idf(liste_tf, liste_idf):
    liste_tf_idf=[]
    for el_tf in liste_tf:
        temp_liste=[]
        for i, element in enumerate(el_tf):
            temp_liste.append(el_tf[i]*liste_idf[i])
        liste_tf_idf.append(temp_liste)
    return liste_tf_idf

def print_topics(lda_mod, elements, nb_t_words):
    for i, j in enumerate(lda_mod.components_):
        print("Thème {}:".format(i))
        print(" ".join([elements[i] for i in j.argsort()[:-nb_t_words - 1:- 1]]))
        
# Nous parcourons tous les fichiers de notre dossier Rapports.

directory = 'Rapports'
conclusions = {}
for filename in os.scandir(directory): 
    if filename.is_file(): 
        obj = PyPDF2.PdfFileReader(filename.path)
        pgno = obj.getNumPages()
        S = "conclusion"
        pgno-=1
        while pgno > -1:
            PgOb = obj.getPage(pgno)
            # vue que le mot conclusion est écrit de plusieurs manières dans le texte, 
            # nous mettons tout en majuscule pour la comparaison
            Text = PgOb.extractText().lower()
            Text_original = PgOb.extractText()
            state = re.search(S,Text)
            pgno-=1
            if state:
                after = Text_original[Text.index(S) + len(S):]
                # print(after)
                # On insert les conclusions dans un dictionnaire dont les clés portent le même noms que les .pdf
                conclusions[filename.name]=after
                break
###############################################################
############# NORMALIZATION DES TROIS CONCLUSIONS  ############
###############################################################
tableau_normalisee={}
for titre, conclusion in conclusions.items(): 
    print()
    #print("################## Conclusion_Norm_",titre,"_################" )
    tableau_normalisee[titre]=conclusions[titre].lower()
    #print(tableau_normalisee[titre])

###############################################################
############# DATA CLEANING DES TROIS CONCLUSIONS  ############
###############################################################

# removing stopwords #7
tableau_RStopWords={}
tableau_RDigits={}
#liststopwords = stopwords.words('french')
#print(liststopwords)
for titre, conclusion in tableau_normalisee.items():
    # Nous recréons une liste de mots (conclusion) sans les signes de ponctuations
    sansPonctuation = " ".join(re.findall(r'\w+', conclusion))
    
    # Tokenization #7
    #print(type(sansPonctuation))
    sansPonctuation=word_tokenize(sansPonctuation)
    tableau_RStopWords[titre] = [word for word in sansPonctuation if word not in stopwords.words('french')]
    #print(tableau_RStopWords[titre])

    # removing digits #7
    tableau_RDigits[titre] = [word for word in tableau_RStopWords[titre] if not word.isdigit()]
    #print(str(tableau_RDigits[titre]))
    
    #Stemming #7
tableau_stemmed={}
for titre, conclusion in tableau_RDigits.items():
    tableau_stemmed[titre]=[]
    #ps = PorterStemmer()
    stemmer = SnowballStemmer(language='french')
    for RD_word in tableau_RDigits[titre]:
        tableau_stemmed[titre].append(stemmer.stem(RD_word))
    #print(tableau_stemmed[titre])

#CountVector 
dic_X={}
liste_complete=[]
tableau_vecteurs={}
for titre, conclusion in tableau_stemmed.items():
    vc = CountVectorizer()
    X = vc.fit_transform(conclusion)
    dic_X[titre]=X
    tableau_vecteurs[titre]=X
    liste_complete+=conclusion
uniqTokenList=list(set(liste_complete))
#print(uniqTokenList)
dictionOutput ={}
for element in liste_complete:
    if element not in dictionOutput:
        dictionOutput[element]=1
    else:
        dictionOutput[element]+=1

##################################################################
#############  Visualisation des données SANS TF-IDF s############
##################################################################

cloud=WordCloud(background_color="white", max_words=50).generate_from_frequencies(dictionOutput)
fig, ax = plt.subplots(1,1,figsize=(15,6))
plt.imshow(cloud, interpolation='bilinear')
plt.axis("off")


#######################################################################
############# CALCUL DU TF-IDF + Visualisation des données ############
#######################################################################
liste_tf_idf=calcul_tf_idf(calcul_tf(tableau_stemmed),calcul_idf(calcul_tf(tableau_stemmed), uniqTokenList))

data=[liste_tf_idf[0],liste_tf_idf[1], liste_tf_idf[2]]

# Data Exploration with TF_IDF

df=pd.DataFrame(data,columns=uniqTokenList)
print("Ex DATF")
cloud=WordCloud(background_color="white", max_words=50)
cloud.fit_words((df.T.sum(axis=1)))
fig, ax = plt.subplots(1,1,figsize=(15,6))
plt.imshow(cloud, interpolation='bilinear')
plt.axis("off")

# implémentation du modèle LDA

#conclusion 1

print()
print("################################################" )
print("################## Conclusion 1 ################" )
print("################################################" )
print()

lda_mod1=LatentDirichletAllocation(
    n_components=20,
    max_iter=5,
    learning_method='online',
    learning_offset=50.,
    random_state=0
    ).fit(dic_X['BEA2016-0759.pdf'])
nb_t_words=15
print_topics(lda_mod1,vc.get_feature_names_out(),nb_t_words)

print()
print("################################################" )
print("################## Conclusion 2 ################" )
print("################################################" )
print()
lda_mod2=LatentDirichletAllocation(
    n_components=20,
    max_iter=5,
    learning_method='online',
    learning_offset=50.,
    random_state=0
    ).fit(dic_X['n-ca001215_05.pdf'])
nb_t_words=15
print_topics(lda_mod2,vc.get_feature_names_out(),nb_t_words)

print()
print("################################################" )
print("################## Conclusion 3 ################" )
print("################################################" )
print()
lda_mod3=LatentDirichletAllocation(
    n_components=20,
    max_iter=5,
    learning_method='online',
    learning_offset=50.,
    random_state=0
    ).fit(dic_X['n-tg000906_06.pdf'])
nb_t_words=15
print_topics(lda_mod3,vc.get_feature_names_out(),nb_t_words)

